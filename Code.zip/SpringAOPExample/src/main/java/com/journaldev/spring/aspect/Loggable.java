package com.journaldev.spring.aspect;

public @interface Loggable {

}
